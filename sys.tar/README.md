sys_inint
=========

## About:
A means to automate the installation of the collection of tools I use every day to initalize servers.

**Not much to see here `@_@`**

