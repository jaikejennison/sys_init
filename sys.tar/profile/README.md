The `.profilerc`
=================
#### *A `.bashrc, .profile , .zshrc` hybrid abomonation!*

## About
Run from this place!  Don't use this file it will be the worst thing ever.  Why oh why would anyone ever commit such a *Horror!!*
# **`@o@`**